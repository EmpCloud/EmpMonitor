{
  "id": "OjUpRAB",
  "mode":"personal",
  "api": "https://activity.dev.empmonitor.com/api/v1/",
  "login": "https://track.dev.empmonitor.com/api/v3/",
  "pipeline": "https://desktop.empmonitor/api/v1/",
  "realtime": "https://desktop.empmonitor/api/v1/",
  "updates": "http://updates.empmonitor.in/dev/"
}
