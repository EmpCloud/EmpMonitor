{
  "id": "OjUpRAB",
  "mode":"office",
  "api": "https://storelogs.dev.empmonitor.com/api/v1/",
  "login": "https://track.empmonitor.com/api/v3/",
  "pipeline": "https://desktop.empmonitor/api/v1/",
  "realtime": "https://desktop.empmonitor/api/v1/",
  "updates": "http://updates.empmonitor.in/"
}
